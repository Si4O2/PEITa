let modInfo = {
	name: "元素周期增量页",
	nameI18N: "Periodic Element Incremental Table", // When you enabled the internationalizationMod, this is the name in the second language
	id: "PEITa_Si4O2's_1st_TMTa",
	author: "二氧化硅硅硅硅/Tetrasilicon dioxide",
	pointsName: "基本粒子",
	pointsNameI18N: "Basic Particles",
	modFiles: ["layers.js", "tree.js"],
	
	internationalizationMod: false,
	// When enabled, it will ask the player to choose a language at the beginning of the game
	changedDefaultLanguage: true,
	// Changes the mod default language. false -> English, true -> Chinese
	
	initialStartPoints: new Decimal(10), // Used for hard resets and new players
	offlineLimit: 24, // In hours
}

var colors = {
	button: {
		width: '250px', // Table Button
		height: '40px', // Table Button
		font: '25px', // Table Button
		border: '3px' // Table Button
	},
	default: {
		1: "#ffffff", //Branch color 1
		2: "#bfbfbf", //Branch color 2
		3: "#7f7f7f", //Branch color 3
		color: "#dfdfdf",
		points: "#ffffff",
		locked: "#bf8f8f",
		background: "#000000",
		background_tooltip: "rgba(0, 0, 0, 0.75)",
	},
}

// When enabled, it will hidden left table
function hiddenLeftTable() {
	return false
}

// Set your version in num and name
let VERSION = {
	num: "0.0.1",
	name: "Literally nothing",
}

function changelog() {
	return i18n(`
		<br><br><br><h1>更新日志:</h1><br>(含有<span style='color: red'>剧透警告</span>)<br><br>
		<span style="font-size: 18.9px;">
		  <br><br>
		  交流群：951232913
		  <br><br>
			<br><br>
			<h3>v0.0.1 前置 2026/10/04</h3><br>
				- 欢迎游玩我的游戏！这是我（二氧化硅硅硅硅）基于元素周期增量树NG版本制作的模组增量页版，与原版较为不同.<br>
				- NG版作者：Eternality_Wind_咏楓⁧~喵⁦<br>
				- 原版作者：溜溜溜达嘿（liuue308）（溜溜溜达嘿太膨胀了）<br>
				- 残局：购买氢升级15<br>
				- 成就数：0（暂时没做）<br>
				- 添加1个层级：（第1周期）氢<br>
				- hope you'll get fun :）<br>
			<br><br>
		`, `
		<br><br>
		- English changelog is unabled
			<br><br>
	`, false)
}

function winText() {
	return i18n(`恭喜你，暂时达到了残局`, `Congratulations! You have reached the end and beaten this game, but for now...`, false)
}

// If you add new functions anywhere inside of a layer, and those functions have an effect when called, add them here.
// (The ones here are examples, all official functions are already taken care of)
var doNotCallTheseFunctionsEveryTick = ["blowUpEverything"]

function getStartPoints() {
	return new Decimal(modInfo.initialStartPoints)
}

// Determines if it should show points/sec
function canGenPoints() {
	return true
}

// Calculate points/sec!
function getPointGen() {
	if (!canGenPoints())
		return new Decimal(0)
	
	let gain = new Decimal(0) // 基础产量为0，只有购买了11号升级才开始生产
	
	// 11号升级：启动生产
	if (hasUpgrade("p", 11)) {
		gain = gain.add(1)
	}
	// 12号升级：x2
	if (hasUpgrade("p", 12)) {
		gain = gain.mul(2)
	}
	// 13号升级：x3
	if (hasUpgrade("p", 13)) {
		gain = gain.mul(3)
	}
	// 14号升级：x4
	if (hasUpgrade("p", 14)) {
		gain = gain.mul(4)
	}
	// 15号升级：氢^0.325 加成
	if (hasUpgrade("p", 15)) {
		gain = gain.mul(player.p.points.pow(0.325))
	}
	
	return gain
}

// You can add non-layer related variables that should to into "player" and be saved here, along with default values
function addedPlayerData() {
	return {}
}

// Display extra information at the top of the page
var displayThings = [
	function() {
		if (options.ch == undefined && modInfo.internationalizationMod == true) { return '<big><br>You should choose your language first<br>你需要先选择语言</big>' }
		return '<div class="res">' + displayThingsRes() + '</div><br><div class="vl2"></div></span>'
	}
]

// You can write code here to easily display information in the top-left corner
function displayThingsRes() {
	return '基本粒子: ' + format(player.points) + ' | '
}

// Determines when the game "ends"
function isEndgame() {
	// 所有升级都买了，并且氢 >= 100
	return hasUpgrade("p", 15)
}

function getPointsDisplay() {
	let a = ''
	if (player.devSpeed && player.devSpeed != 1) {
		a += options.ch ? '<br>时间加速: ' + format(player.devSpeed) + 'x' : '<br>Dev Speed: ' + format(player.devSpeed) + 'x'
	}
	if (player.offTime !== undefined) {
		a += options.ch ? '<br>离线加速剩余时间: ' + formatTime(player.offTime.remain) : '<br>Offline Time: ' + formatTime(player.offTime.remain)
	}
	a += '<br>'
	if (!(options.ch == undefined && modInfo.internationalizationMod == true)) {
		a += `<span class="overlayThing">${(i18n("你有", "You have", false))} <h2 class="overlayThing" id="points"> ${format(player.points)}</h2> ${i18n(modInfo.pointsName, modInfo.pointsNameI18N)}</span>`
		if (canGenPoints()) {
			a += `<br><span class="overlayThing">(` + (tmp.other.oompsMag != 0 ? format(tmp.other.oomps) + " OoM" + (tmp.other.oompsMag < 0 ? "^OoM" : tmp.other.oompsMag > 1 ? "^" + tmp.other.oompsMag : "") + "s" : formatSmall(getPointGen())) + `/sec)</span>`
		}
		a += `<div style="margin-top: 3px"></div>`
	}
	a += tmp.displayThings
	a += '<br><br>'
	return a
}

// Less important things beyond this point!

// Style for the background, can be a function
var backgroundStyle = {
	
}

// You can change this if you have things that can be messed up by long tick lengths
function maxTickLength() {
	return (3600) // Default is 1 hour which is just arbitrarily large
}

// Use this if you need to undo inflation from an older version. If the version is older than the version that fixed the issue,
// you can cap their current resources with this.
function fixOldSave(oldVersion) {}