addLayer("p1", {
    name: "p1",
    position: -1,
    row: 0,
    symbol() {return '↓ 周期 1 ↓'}, // This appears on the layer's node. Default is the id with the first letter capitalized
    symbolI18N() {return '↓ layer 1 ↓'}, // Second name of symbol for internationalization (i18n) if internationalizationMod is enabled (in mod.js)
    small: true,// Set to true to generate a slightly smaller layer node
    nodeStyle: {"font-size": "21px", "height": "40px"},// Style for the layer button
    startData() { return {
        unlocked: true,
        points: new Decimal(0),// This currently does nothing, but it's required. (Might change later if you add mechanics to this layer.)
    }},
    color: "#fefefe",
    type: "none",
    tooltip(){return false},
    layerShown(){return layerDisplayTotal(['p'])},// If any layer in the array is unlocked, it will returns true. Otherwise it will return false.
	tabFormat: [
        ["display-text", function() { return getPointsDisplay() }]
    ],
})

addLayer("p", {
    name: "hydrogen", // This is optional, only used in a few places, If absent it just uses the layer id
    symbol: "氢/Hydrogen", // This appears on the layer's node. Default is the id with the first letter capitalized
    symbolI18N: "Prestige", // Second name of symbol for internationalization (i18n) if internationalizationMod is enabled
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    row: 0, // Row the layer is in on the tree (0 is the first row)
    startData() { return {
        unlocked: true,
		points: new Decimal(0),
    }},
    color: "#ff6ae6",
    requires: new Decimal(10), // Can be a function that takes requirement increases into account
    resource: "氢", // Name of prestige currency
    resourceI18N: "prestige points", // Second name of the resource for internationalization (i18n) if internationalizationMod is enabled
    baseResource: "基本粒子", // Name of resource prestige is based on
    baseResourceI18N: "points", // Second name of the baseResource for internationalization (i18n) if internationalizationMod is enabled
    baseAmount() {return player.points}, // Get the current amount of baseResource
    type: "normal", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.5, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new Decimal(1)
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        return new Decimal(1)
    },
    upgrades: {
        11: {
            title: "元神启动！",
            titleI18N: "00 Start",
            description: "开始生产基本粒子",
            descriptionI18N: "Gain 1 point every second.",
            cost: function() { return new Decimal(0) }, // 改为 0，让玩家一开始就能免费购买
            unlocked() { return true },
            effect() { return new Decimal(1) },
            effectDisplay() { return "已启动" }
        },
        12: {
            title: "加速生产1",
            titleI18N: "Speed Up 1",
            description: "基本粒子获取 x2",
            descriptionI18N: "Basic particle gain x2",
            cost: function() { return new Decimal(5) },
            unlocked() { return hasUpgrade("p", 11) },
        },
        13: {
            title: "加速生产2",
            titleI18N: "Speed Up 2",
            description: "基本粒子获取 x3",
            descriptionI18N: "Basic particle gain x3",
            cost: function() { return new Decimal(10) },
            unlocked() { return hasUpgrade("p", 12) },
        },
        14: {
            title: "加速生产3",
            titleI18N: "Speed Up 3",
            description: "基本粒子获取 x4",
            descriptionI18N: "Basic particle gain x4",
            cost: function() { return new Decimal(20) },
            unlocked() { return hasUpgrade("p", 13) },
        },
        15: {
    title: "氢原子",
    titleI18N: "Hydrogen Atom",
    description: "氢加成基本粒子获取（^0.325）",
    descriptionI18N: "Hydrogen boosts basic particle gain: hydrogen^0.325",
    cost: function() { return new Decimal(35) },
    unlocked() { return hasUpgrade("p", 14) },
    // 新增下面两行
    effect() {
        // 如果没购买，返回 1（不产生影响），避免报错
        if (!hasUpgrade("p", 15)) return new Decimal(1);
        return player.p.points.pow(0.325);
    },
    effectDisplay() {
    // 未购买时显示“购买后: x...”作为预览
    if (!hasUpgrade("p", 15)) return "  x" + format(player.p.points.pow(0.325));
    return "x" + format(this.effect());
},
},
    },
    hotkeys: [
        {key: "H", description: "H: 进行一次氢重置", onPress(){if (canReset(this.layer)) doReset(this.layer)}},
    ],
    microtabs:{
        tab:{
            "main":{
                name(){return 'main'}, // Name of tab button
                nameI18N(){return 'main'}, // Second name for internationalization (i18n) if internationalizationMod is enabled
               content: [
    ["row", [
        ["upgrade", 11],
        ["upgrade", 12],
        ["upgrade", 13],
        ["upgrade", 14],
        ["upgrade", 15],
    ]]
],
            },
            "another":{
                name(){return 'another'},
                nameI18N(){return 'another'},
                content:[
                ],
            }
        },
    },
    tabFormat: [
       ["display-text", function() { return getPointsDisplay() }],
       "main-display",
       "prestige-button",
       "blank",
       ["microtabs","tab"]
    ],
    layerShown(){return true},
})

// You can delete the second name from each option if internationalizationMod is not enabled.
// You can use function i18n(text, otherText) to return text in two different languages. Typically, text is English and otherText is Chinese. If changedDefaultLanguage is true, its reversed